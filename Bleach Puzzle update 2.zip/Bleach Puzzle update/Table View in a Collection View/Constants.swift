//
//  Constants.swift
//  Bleach Puzzle
//
//  Created by Mamta Devi on 13/03/19.
//  Copyright © 2019 Ash Furrow. All rights reserved.
//

import Foundation
import UIKit

let USER_DEFAULT = UserDefaults.standard
let APP_DELEGATE = UIApplication.shared.delegate as! AppDelegate

struct USERDEFAULT_KEY {
    static let BEST_VALUES = "bestValues"
}

