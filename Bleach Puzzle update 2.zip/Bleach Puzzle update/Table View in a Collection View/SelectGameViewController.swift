//
//  SelectGameViewController.swift
//  BANGOU_GAME
//
//  Created by pc on 10/31/17.
//  Copyright © 2017 pc. All rights reserved.
//

import UIKit
import AVFoundation
import StoreKit
//import RageProducts

class SelectGameViewController: UIViewController
{
    
    @IBOutlet var btn_share: UIButton!
    @IBOutlet var btn_music: UIButton!
    
    var play:Bool = false
    var audioPlayer: AVAudioPlayer?
    var sTr_gameLevel = ""
    var lbl_view_easy_sTr = ""
    var txt_view_edit_sTr = ""

    @IBOutlet var btn_extreme: UIButton!
    @IBOutlet var btn_easy: UIButton!
    @IBOutlet var btn_hard: UIButton!
    @IBOutlet weak var btn_medium: UIButton!
    var sTr_how_play = ""
    
    
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        btn_music.isHidden=true
        btn_share.isHidden=true
        
//          playBackgroundMusic()

        btn_easy.layer.cornerRadius = 10;
        btn_hard.layer.cornerRadius = 10; // this value vary as per your desire
        btn_medium.layer.cornerRadius = 10;
//        btn_extreme.layer.cornerRadius = 10; // this value vary as per your desire

//        btn_extreme.layer.cornerRadius = 10;
        
        let sTr_sound = UserDefaults.standard.object(forKey: "music") as? String
        
        if sTr_sound == "on" {
            btn_music.setImage(UIImage(named: "sound"), for: .normal)
        }else{
            play = true
            btn_music.setImage(UIImage(named: "mute"), for: .normal)
        }
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
//        playBackgroundMusic()
        super.viewWillAppear(animated) // No need for semicolon
    }
    
    @IBAction func MediumClick(_ sender: Any) {
      
            let push = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "collectViewController") as! collectViewController
        push.str_lvl = "Medium"
//        push.lbl_view_easy_sTr = "Medium"
       // push.txt_view_edit_sTr = launch4

            self.navigationController?.pushViewController(push, animated: true)
    }
    @IBAction func ExtremeClick(_ sender: Any)
    {
       
            let push = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "collectViewController") as! collectViewController
            push.str_lvl = "Extreme"

        //        push.lbl_view_easy_sTr = "Extreme"
//        //push.txt_view_edit_sTr = launch3
            self.navigationController?.pushViewController(push, animated: true)
    }
//    
//    var buyButtonHandler: ((_ product: SKProduct) -> ())?
//    var product: SKProduct? {
//        didSet {
//            guard let product = product else { return }
//            
////            textLabel?.text = product.localizedTitle
//            
//            if RageProducts.store.isProductPurchased(product.productIdentifier) {
////                accessoryType = .checkmark
////                accessoryView = nil
////                detailTextLabel?.text = ""
//            }
//            else if IAPHelper.canMakePayments()
//            {
////                ProductCell.priceFormatter.locale = product.priceLocale
////                detailTextLabel?.text = ProductCell.priceFormatter.string(from: product.price)
////
////                accessoryType = .none
////                accessoryView = self.newBuyButton()
//            } else {
////                detailTextLabel?.text = "Not available"
//            }
//        }
//    }
    
    @IBAction func btn_for_hard(_ sender: UIButton)
    {
      let push = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "collectViewController") as! collectViewController
       push.str_lvl = "Hard"

        //push.lbl_view_easy_sTr = "Hard"
        //push.txt_view_easy_
        self.navigationController?.pushViewController(push, animated: true)
    }
    
    @IBAction func backClick(_ sender: Any)
    {
        //let push = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ViewController0") as! ViewController0

        self.navigationController?.popToRootViewController(animated: true)
    }
    
    
    @IBAction func btn_for_easy(_ sender: UIButton)
    {
       
            let push = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "collectViewController") as! collectViewController
        push.str_lvl = "Easy"
        //push.lbl_view_easy_sTr = "Easy"
        //push.txt_view_edit_sTr = launch1
            self.navigationController?.pushViewController(push, animated: true)
    }
    
    @IBAction func btn_for_Share(_ sender: UIButton)
    {
        let message = "BANGOU_APP"
        //Set the link to share.
        if let link = NSURL(string: "https://marvelapp.com/42dcj2b/screen/33606755")
        {
            let objectsToShare = [message,link] as [Any]
            let activityVC = UIActivityViewController(activityItems: objectsToShare, applicationActivities: nil)
            activityVC.excludedActivityTypes = [UIActivityType.airDrop, UIActivityType.addToReadingList]
            self.present(activityVC, animated: true, completion: nil)
        }
    }
    
    
    @IBAction func btn_for_music(_ sender: UIButton)
    {
         playBackgroundMusic()
    }
    
    func play_music()
    {
       
        if play == false
        {
            play = true
//            audioPlayer?.stop()
            btn_music.setImage(UIImage(named: "mute"), for: .normal)
            UserDefaults.standard.set("off", forKey: "music")
        }else{
            play = false
//                audioPlayer?.numberOfLoops = -1
//               audioPlayer?.play()
            btn_music.setImage(UIImage(named: "sound"), for: .normal)
            UserDefaults.standard.set("on", forKey: "music")
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func playBackgroundMusic()
    {
        let aSound = NSURL(fileURLWithPath: Bundle.main.path(forResource: "mario", ofType: "mp3")!)
        do {
            audioPlayer = try AVAudioPlayer(contentsOf:aSound as URL)
            audioPlayer!.prepareToPlay()
            play_music()

        } catch
        {
            print("Cannot play the file")
        }
    }
    
    override func viewWillDisappear(_ animated: Bool)
    {
        play = true
        audioPlayer?.stop()
    }
    
    
}
