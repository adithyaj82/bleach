//
//  AboutViewController.swift
//  iPuzzle9
//
//  Created by adithya on 1/21/19.
//  Copyright © 2019 akhil. All rights reserved.
//

import UIKit

class AboutViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

 
    @IBAction func disms(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)

//        dismiss(animated: true, completion: nil)
    }
}
