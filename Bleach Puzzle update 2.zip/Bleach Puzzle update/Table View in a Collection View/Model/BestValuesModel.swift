//
//  BestValuesModel.swift
//  Bleach Puzzle
//
//  Created by Mamta Devi on 13/03/19.
//  Copyright © 2019 Ash Furrow. All rights reserved.
//

import UIKit

class BestValuesModel: NSObject, NSCoding {
    var easyLevelBestTime: Int?
    var mediumLevelBestScore: Int?
    var hardLevelBestScore: Int?
    
    override init() {
        
    }
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(self.easyLevelBestTime, forKey: "easyLevelBestTime")
        aCoder.encode(self.mediumLevelBestScore, forKey: "mediumLevelBestScore")
        aCoder.encode(self.hardLevelBestScore, forKey: "hardLevelBestScore")
    }
    
    required init?(coder aDecoder: NSCoder) {
        self.easyLevelBestTime = aDecoder.decodeObject(forKey: "easyLevelBestTime") as? Int
        self.mediumLevelBestScore = aDecoder.decodeObject(forKey: "mediumLevelBestScore") as? Int
        self.hardLevelBestScore = aDecoder.decodeObject(forKey: "hardLevelBestScore") as? Int
    }
}
