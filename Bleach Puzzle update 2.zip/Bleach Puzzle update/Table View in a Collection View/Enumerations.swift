//
//  Enumerations.swift
//  Bleach Puzzle
//
//  Created by Mamta Devi on 14/03/19.
//  Copyright © 2019 Ash Furrow. All rights reserved.
//

import Foundation
import UIKit

enum Colors {
        static let red = UIColor(red: 1.0, green: 0.0, blue: 77.0/255.0, alpha: 1.0)
        static let blue = UIColor(red: 127.0/255.0, green: 208.0/255.0, blue: 250.0/255.0, alpha: 1.0)
            static let green = UIColor.green
    //    static let green = UIColor(red: 35.0/255.0 , green: 233/255, blue: 173/255.0, alpha: 1.0)
        static let yellow = UIColor(red: 1, green: 209/255, blue: 77.0/255.0, alpha: 1.0)
    
}
enum LevelType: String{
    case easy = "Easy"
    case medium = "Medium"
    case hard = "Hard"
}

enum AppraiselType: String {
    case excellent = "Excellent"
    case gameOver = "Game Over"
}

enum Images{
    static let box: UIImage = #imageLiteral(resourceName: "ss") //UIImage(named: "ss")!
    // static let triangle = UIImage(named: "Triangle")!
    static let circle: UIImage = #imageLiteral(resourceName: "ss")
    static let swirl: UIImage = #imageLiteral(resourceName: "Spiral")
}
