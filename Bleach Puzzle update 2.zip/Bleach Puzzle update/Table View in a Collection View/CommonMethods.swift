//
//  CommonMethods.swift
//  Bleach Puzzle
//
//  Created by Mamta Devi on 15/03/19.
//  Copyright © 2019 Ash Furrow. All rights reserved.
//

import UIKit

class CommonMethods: NSObject {
    func saveBestValuesData(obj: BestValuesModel) {
        let data = NSKeyedArchiver.archivedData(withRootObject: obj)
        USER_DEFAULT.set(data, forKey: USERDEFAULT_KEY.BEST_VALUES)
        
        USER_DEFAULT.synchronize()
    }
    
    func getBestValuesData() -> BestValuesModel{
        let data = USER_DEFAULT.value(forKey: USERDEFAULT_KEY.BEST_VALUES)
        let obj = NSKeyedUnarchiver.unarchiveObject(with: data as! Data) as! BestValuesModel
        print(obj)
        return obj
    }
}
