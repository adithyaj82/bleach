import UIKit


@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        Thread.sleep(forTimeInterval: 3.0)

        if USER_DEFAULT.value(forKey: USERDEFAULT_KEY.BEST_VALUES) == nil {
            let obj = BestValuesModel()
            obj.easyLevelBestTime = 0
            obj.mediumLevelBestScore = 0
            obj.hardLevelBestScore = 0
            self.saveBestValuesData(obj: obj)
        }
        
        return true
    }
    func saveBestValuesData(obj: BestValuesModel) {
        let data = NSKeyedArchiver.archivedData(withRootObject: obj)
        USER_DEFAULT.set(data, forKey: USERDEFAULT_KEY.BEST_VALUES)
        
        USER_DEFAULT.synchronize()
    }
    
    func fetchBestValuesData() -> BestValuesModel {
        let data = USER_DEFAULT.value(forKey: USERDEFAULT_KEY.BEST_VALUES)
        let obj = NSKeyedUnarchiver.unarchiveObject(with: data as! Data) as! BestValuesModel
        print(obj)
        return obj
    }
}
