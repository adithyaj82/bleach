//
//  gameOverView.swift
//  BANGOU_GAME
//
//  Created by mac on 12/19/17.
//  Copyright © 2017 pc. All rights reserved.
//

import UIKit
import AVFoundation


class gameOverView: UIViewController {
    @IBOutlet var lbl_main1: UILabel!
    @IBOutlet var lbl_main3: UILabel!
    @IBOutlet var lbl_main2: UILabel!
    @IBOutlet weak var appraiselLbl: UILabel?
    @IBOutlet var img_3: UIImageView!
    @IBOutlet var img_1: UIImageView!
    @IBOutlet var img_2: UIImageView!
    @IBOutlet var lbl_besttime: UILabel!
    var sTr_score = ""
    var sTr_time = ""
    @IBOutlet var lbl_time: UILabel!
    @IBOutlet var btn_newgame: UIButton!
    @IBOutlet var lbl_gamelevel: UILabel!
    @IBOutlet var lbl_record: UILabel!
    var isGameOver: Bool?
    var gameLevel: String?
    var appraisel: String?
    var time : String?
    var score: String?
    
    var pianoSound = NSURL(fileURLWithPath: Bundle.main.path(forResource: "Complete game", ofType: "wav")!)
    var audioPlayer = AVAudioPlayer()
    var emitter = CAEmitterLayer()
    
    var colors:[UIColor] = [
        Colors.yellow,
        Colors.blue,
        Colors.green,
        Colors.red
    ]
    
    var images:[UIImage] = [
        Images.box,
        Images.circle,
        Images.box
    ]
    
    var velocities:[Int] = [
        50,
        40,
        100,
        150
    ]
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        appraiselLbl?.text = appraisel

        lbl_gamelevel.text = gameLevel!
        let obj: BestValuesModel = APP_DELEGATE.fetchBestValuesData()
        if LevelType.easy.rawValue == gameLevel{
            let timeArray1 = self.secondsToHoursMinutesSeconds(seconds: Int(self.time!)!)
            let timeArray2 = self.secondsToHoursMinutesSeconds(seconds: obj.easyLevelBestTime!)
            lbl_time.text = String(format:"%.2d:%.2d",timeArray1.1,timeArray1.2 )
            lbl_besttime.text = String(format:"%.2d:%.2d",timeArray2.1,timeArray2.2 )
        }else if LevelType.medium.rawValue == gameLevel{
            lbl_time.text = self.score
            lbl_besttime.text = String(format:"%.2d", obj.mediumLevelBestScore!)

        }else{
            lbl_time.text = self.score
            lbl_besttime.text = String(format:"%.2d", obj.hardLevelBestScore!)
        }
        if gameLevel! == LevelType.easy.rawValue {
           lbl_main2.text = "Time"
            lbl_main3.text = "Best Time"
            img_2.image = #imageLiteral(resourceName: "time28x28")
            img_3.image = #imageLiteral(resourceName: "besttime64x64")
            
        }else{
           lbl_main2.text = "Score"
            lbl_main3.text = "Best Score"
            
            img_2.image = #imageLiteral(resourceName: "score64x64")
            img_3.image = #imageLiteral(resourceName: "bestscore64x64")
        }
       // lbl_time.text = sTr_time
      //  lbl_besttime.text = sTr_score
        
        UIView.animate(withDuration: 0.8, delay: 0.8, usingSpringWithDamping: 0.8, initialSpringVelocity: 0, options: .curveEaseInOut, animations:
            {
                self.lbl_time.center.x = self.view.bounds.width - 200
                self.lbl_besttime.center.x = self.view.bounds.width - 200
                self.lbl_gamelevel.center.x = self.view.bounds.width - 200
        }, completion: nil)
        
        self.lbl_time.center.x = self.view.bounds.width - 100
        self.lbl_besttime.center.x = self.view.bounds.width - 100
        self.lbl_gamelevel.center.x = self.view.bounds.width - 100
        btn_newgame.layer.cornerRadius = 10;
        
        // Do any additional setup after loading the view.
    }
    func secondsToHoursMinutesSeconds (seconds : Int) -> (Int, Int, Int) {
        return (seconds / 3600, (seconds % 3600) / 60, (seconds % 3600) % 60)
    }
    func playBackgroundMusic()
    {
        let aSound = NSURL(fileURLWithPath: Bundle.main.path(forResource: "Complete game", ofType: "wav")!)
        do{
            audioPlayer = try AVAudioPlayer(contentsOf:aSound as URL)
            audioPlayer.prepareToPlay()
            audioPlayer.play()
        }catch{
            print("Cannot play the file")
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        audioPlayer.stop()
    }
         @IBAction func newGameClick(_ sender: Any)
    {
        let push = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SelectGameViewController") as! SelectGameViewController
        self.navigationController?.pushViewController(push, animated: true)
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        emitter.emitterPosition = CGPoint(x: self.view.frame.size.width / 2, y: -10)
        emitter.emitterShape = kCAEmitterLayerLine
        emitter.emitterSize = CGSize(width: self.view.frame.size.width, height: 2.0)
        emitter.emitterCells = generateEmitterCells()
        self.view.layer.addSublayer(emitter)
        playBackgroundMusic()
    }
    
    private func generateEmitterCells() -> [CAEmitterCell] {
        var cells:[CAEmitterCell] = [CAEmitterCell]()
        for index in 0..<8
        {
            let cell = CAEmitterCell()
            cell.birthRate = 2.0
            cell.lifetime = 8.0
            cell.lifetimeRange = 0
            cell.velocity = CGFloat(getRandomVelocity())
            cell.velocityRange = 0
            cell.emissionLongitude = CGFloat(Double.pi)
            cell.emissionRange = 0.5
            cell.spin = 0
            cell.spinRange = 0
            if gameLevel != LevelType.easy.rawValue {
            cell.color = getNextColor(i: index)
            }
            cell.contents = getNextImage(i: index)
            cell.scaleRange = 0.15
            cell.scale = 0.2
            cells.append(cell)
        }
        return cells
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    private func getRandomVelocity() -> Int {
        return velocities[getRandomNumber()]
    }
    
    private func getRandomNumber() -> Int {
        return Int(arc4random_uniform(4))
    }
    
    private func getNextImage(i:Int) -> CGImage {
        return images[i % 2].cgImage!
    }
    
    private func getNextColor(i:Int) -> CGColor {
        if i <= 2 {
            return colors[0].cgColor
        } else if i <= 4 {
            return colors[1].cgColor
        } else if i <= 6 {
            return colors[2].cgColor
        } else {
            return colors[3].cgColor
        }
    }
}
