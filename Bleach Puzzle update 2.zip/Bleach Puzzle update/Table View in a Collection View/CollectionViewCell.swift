//
//  CollectionViewCell.swift
//  Collection View in a Table View Cell
//
//  Created by adithya on 2/18/19.
//  Copyright © 2019 Ash Furrow. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var img: UIImageView!
}
