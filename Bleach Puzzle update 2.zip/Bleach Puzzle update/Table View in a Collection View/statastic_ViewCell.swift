//
//  statastic_ViewCell.swift
//  BANGOU_GAME
//
//  Created by mac on 3/10/18.
//  Copyright © 2018 pc. All rights reserved.
//

import UIKit

class statastic_ViewCell: UITableViewCell {

    @IBOutlet var lbl_name: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
