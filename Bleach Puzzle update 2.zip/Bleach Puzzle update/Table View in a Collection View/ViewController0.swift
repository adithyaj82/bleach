//
//  ViewController0.swift
//  iPuzzle9
//
//  Created by adithya on 1/16/19.
//  Copyright © 2019 akhil. All rights reserved.
//

import UIKit

class ViewController0: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
       // MusicManager.shared.playBackgroundMusic()

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func btnTapped(_ sender: UIButton) {
        
        if sender.currentImage == UIImage(named: "sound1"){
            
            sender.setImage(UIImage(named: "sound2"), for: .normal)
           // MusicManager.shared.playBackgroundMusic()

        }else{
            
            sender.setImage(UIImage(named: "sound1"), for: .normal)
         //   MusicManager.shared.pauseBackgroundMusic()

        }
    }
    @IBAction func plays(_ sender: Any) {
        let push = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SelectGameViewController") as! SelectGameViewController
        
        self.navigationController?.pushViewController(push, animated: true)
        
        
        
    }
    
    @IBAction func about(_ sender: Any) {
        let push = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "AboutViewController") as! AboutViewController
        
        self.navigationController?.pushViewController(push, animated: true)
        
        
        
    }
    @IBAction func instruct(_ sender: Any) {
        let push = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "InstructionsViewController") as! InstructionsViewController
        
        self.navigationController?.pushViewController(push, animated: true)
        
        
        
    }
}
