//
//  collectViewController.swift
//  Collection View in a Table View Cell
//
//  Created by adithya on 2/18/19.
//  Copyright © 2019 Ash Furrow. All rights reserved.
//

import UIKit

class collectViewController: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate {
    let model = generateRandomData()
    @IBOutlet var lvlName: UILabel!
    @IBOutlet weak var lbl_for_best_Score: UILabel!
    @IBOutlet weak var lbl_for_bestTimes: UILabel!
    @IBOutlet var lbl_bestTime: UILabel!
    weak var timer: Timer?
    var timerValue = 0
    var easyLevelScore: Int? = 0
    
    var str_lvl = ""
    var characters:[UIImage?] = [#imageLiteral(resourceName: "11.png"),#imageLiteral(resourceName: "12.png"),#imageLiteral(resourceName: "13.png"),#imageLiteral(resourceName: "14.png"),#imageLiteral(resourceName: "15.png"),#imageLiteral(resourceName: "16.png"),#imageLiteral(resourceName: "17.png"),#imageLiteral(resourceName: "18.png"),#imageLiteral(resourceName: "19.png"),#imageLiteral(resourceName: "20.png"),#imageLiteral(resourceName: "21.png"),#imageLiteral(resourceName: "22.png"),#imageLiteral(resourceName: "23.png"),#imageLiteral(resourceName: "24.png"),#imageLiteral(resourceName: "25.png"),#imageLiteral(resourceName: "26.png"),#imageLiteral(resourceName: "27.png"),#imageLiteral(resourceName: "28.png"),#imageLiteral(resourceName: "29.png"),#imageLiteral(resourceName: "30.png"),#imageLiteral(resourceName: "31.png"),#imageLiteral(resourceName: "32.png"),#imageLiteral(resourceName: "33.png"),#imageLiteral(resourceName: "34.png"),#imageLiteral(resourceName: "35.png"),#imageLiteral(resourceName: "36.png"),#imageLiteral(resourceName: "37.png"),#imageLiteral(resourceName: "38.png"),#imageLiteral(resourceName: "39.png"),#imageLiteral(resourceName: "40.png"),#imageLiteral(resourceName: "41.png"),#imageLiteral(resourceName: "42.png"),#imageLiteral(resourceName: "43.png"),#imageLiteral(resourceName: "44.png"),#imageLiteral(resourceName: "45.png"),#imageLiteral(resourceName: "46.png"),#imageLiteral(resourceName: "47.png"),#imageLiteral(resourceName: "48.png"),#imageLiteral(resourceName: "50.png"),#imageLiteral(resourceName: "51.png"),#imageLiteral(resourceName: "52.png"),#imageLiteral(resourceName: "53.png"),#imageLiteral(resourceName: "54.png"),#imageLiteral(resourceName: "55.png"),#imageLiteral(resourceName: "49.png"),#imageLiteral(resourceName: "11.png"),#imageLiteral(resourceName: "12.png"),#imageLiteral(resourceName: "13.png"),#imageLiteral(resourceName: "14.png"),#imageLiteral(resourceName: "15.png"),#imageLiteral(resourceName: "16.png"),#imageLiteral(resourceName: "17.png"),#imageLiteral(resourceName: "18.png"),#imageLiteral(resourceName: "19.png"),#imageLiteral(resourceName: "20.png"),#imageLiteral(resourceName: "21.png"),#imageLiteral(resourceName: "22.png"),#imageLiteral(resourceName: "23.png"),#imageLiteral(resourceName: "24.png"),#imageLiteral(resourceName: "25.png"),#imageLiteral(resourceName: "26.png"),#imageLiteral(resourceName: "27.png"),#imageLiteral(resourceName: "28.png"),#imageLiteral(resourceName: "29.png"),#imageLiteral(resourceName: "30.png"),#imageLiteral(resourceName: "31.png"),#imageLiteral(resourceName: "32.png"),#imageLiteral(resourceName: "33.png"),#imageLiteral(resourceName: "34.png"),#imageLiteral(resourceName: "35.png"),#imageLiteral(resourceName: "36.png"),#imageLiteral(resourceName: "37.png"),#imageLiteral(resourceName: "38.png"),#imageLiteral(resourceName: "39.png"),#imageLiteral(resourceName: "40.png"),#imageLiteral(resourceName: "41.png"),#imageLiteral(resourceName: "42.png"),#imageLiteral(resourceName: "43.png"),#imageLiteral(resourceName: "44.png"),#imageLiteral(resourceName: "45.png"),#imageLiteral(resourceName: "46.png"),#imageLiteral(resourceName: "47.png"),#imageLiteral(resourceName: "48.png"),#imageLiteral(resourceName: "50.png"),#imageLiteral(resourceName: "51.png"),#imageLiteral(resourceName: "52.png"),#imageLiteral(resourceName: "53.png"),#imageLiteral(resourceName: "54.png"),#imageLiteral(resourceName: "55.png"),#imageLiteral(resourceName: "49.png")]
    fileprivate var longPressGesture: UILongPressGestureRecognizer!
    override func viewDidLoad() {
        super.viewDidLoad()
        lvlName.text =  str_lvl
        if str_lvl == "Hard"||str_lvl == "Medium"{
            lbl_for_bestTimes.text = "Best Score"
            self.lbl_bestTime.text = String(format: "00")
            let obj : BestValuesModel = APP_DELEGATE.fetchBestValuesData()
            if str_lvl == "Hard"{
                self.lbl_for_best_Score.text = String(format: "%.2d", obj.hardLevelBestScore!)
            }else{
                self.lbl_for_best_Score.text = String(format: "%.2d", obj.mediumLevelBestScore!)
            }
        }else{
            lbl_for_bestTimes.text = "Best Time"
            self.lbl_bestTime.text = String(format: "00:00")
                self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.setTimer), userInfo: nil, repeats: true)
            let obj : BestValuesModel = APP_DELEGATE.fetchBestValuesData()
           
            let timeArray = self.secondsToHoursMinutesSeconds(seconds: obj.easyLevelBestTime!)
            self.lbl_for_best_Score.text = String(format: "%.2d:%.2d", timeArray.1, timeArray.2)
            
        }
        longPressGesture = UILongPressGestureRecognizer(target: self, action: #selector(self.handleLongGesture(gesture:)))
        collect.addGestureRecognizer(longPressGesture)
        
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        characters.shuffle()
    }
    @IBOutlet var collect: UICollectionView!
    
    func setTimer() {
        if timerValue != 600 && self.easyLevelScore != 450{
         DispatchQueue.main.async {
            self.timerValue = self.timerValue + 1
            let timeArray = self.secondsToHoursMinutesSeconds(seconds: self.timerValue)
       
        self.lbl_bestTime.text = String(format: "%.2d:%.2d", timeArray.1, timeArray.2)
            
        }
        }else{
            timer?.invalidate()
            var obj: BestValuesModel = APP_DELEGATE.fetchBestValuesData()
            if obj.easyLevelBestTime! > timerValue || obj.easyLevelBestTime! == 0 {
                obj.easyLevelBestTime = timerValue
                APP_DELEGATE.saveBestValuesData(obj: obj)
            }
            if self.easyLevelScore == 450{
            self.navigateToGameOverScreen(appraiselStr: AppraiselType.excellent.rawValue)
            }else{
                self.navigateToGameOverScreen(appraiselStr: AppraiselType.gameOver.rawValue)
            }
        }
    }
    func secondsToHoursMinutesSeconds (seconds : Int) -> (Int, Int, Int) {
        return (seconds / 3600, (seconds % 3600) / 60, (seconds % 3600) % 60)
    }
    @IBAction func backClick(_ sender: Any)
    {
        //        let push = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Select
    
        self.navigationController?.popViewController(animated: true)
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 90
    }
    
    
    func collectionView (_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CollectionViewCell
        
        cell.backgroundColor = model[collectionView.tag][indexPath.item]
        cell.img?.image = characters[indexPath.item]
        
        return cell
    }
    
    
    func setCollectionViewDataSourceDelegate<D: UICollectionViewDataSource & UICollectionViewDelegate>(_ dataSourceDelegate: D, forRow row: Int) {
        
        collect.delegate = dataSourceDelegate
        collect.dataSource = dataSourceDelegate
        collect.tag = row
        collect.reloadData()
    }
    
    var collectionViewOffset: CGFloat {
        set { collect.contentOffset.x = newValue }
        get { return collect.contentOffset.x }
    }
    
    
    func collectionView(_ collectionView: UICollectionView, canMoveItemAt indexPath: IndexPath) -> Bool {
        return true
    }
    func collectionView(_ collectionView: UICollectionView, moveItemAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        
        let img = characters.remove(at: sourceIndexPath.row)
        characters.insert(img, at: destinationIndexPath.row)
        if (destinationIndexPath.row > 0) &&  (characters[destinationIndexPath.row] == characters[destinationIndexPath.row - 1]) {
            characters.remove(at: destinationIndexPath.row)
            characters.insert(nil, at: destinationIndexPath.row)
            characters.remove(at: destinationIndexPath.row - 1)
            characters.insert(nil, at: destinationIndexPath.row - 1)
           self.updateScore()
        }else if (destinationIndexPath.row < characters.count - 1 ) && (characters[destinationIndexPath.row] == characters[destinationIndexPath.row + 1]) {
            characters.remove(at: destinationIndexPath.row)
            characters.insert(nil, at: destinationIndexPath.row)
            characters.remove(at: destinationIndexPath.row + 1)
            characters.insert(nil, at: destinationIndexPath.row + 1)
            self.updateScore()
        }else if (destinationIndexPath.row < characters.count - 5) && (characters[destinationIndexPath.row] == characters[destinationIndexPath.row + 4]) {
            characters.remove(at: destinationIndexPath.row)
            characters.insert(nil, at: destinationIndexPath.row)
            characters.remove(at: destinationIndexPath.row + 4)
            characters.insert(nil, at: destinationIndexPath.row + 4)
            self.updateScore()
        }else if (destinationIndexPath.row > 3) && (characters[destinationIndexPath.row] == characters[destinationIndexPath.row - 4]) {
            characters.remove(at: destinationIndexPath.row)
            characters.insert(nil, at: destinationIndexPath.row)
            characters.remove(at: destinationIndexPath.row - 1)
            characters.insert(nil, at: destinationIndexPath.row - 1)
            self.updateScore()
        }
    }
    func updateScore(){
         self.collect.reloadData()
        if str_lvl == "Hard"||str_lvl == "Medium"{
            self.lbl_bestTime.text = String(format: "%.2d", Int(self.lbl_bestTime.text!)! + 10)
            
            if self.lbl_bestTime.text == "450"{
                var obj: BestValuesModel = APP_DELEGATE.fetchBestValuesData()
                
                let val: Int = Int((self.lbl_bestTime.text!))!
                if LevelType.medium.rawValue == str_lvl{
                    if obj.mediumLevelBestScore! < val {
                        obj.mediumLevelBestScore = Int(self.lbl_bestTime.text!)!
                    }
                }else{
                    if obj.hardLevelBestScore! < val {
                        obj.hardLevelBestScore = Int(self.lbl_bestTime.text!)!
                        
                    }
                }
                APP_DELEGATE.saveBestValuesData(obj: obj)
                
                self.navigateToGameOverScreen(appraiselStr: AppraiselType.excellent.rawValue)
            }
        }else{
            self.easyLevelScore = self.easyLevelScore! + 1
        }
       
        
    }
    func navigateToGameOverScreen(appraiselStr: String){
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "gameOverView") as? gameOverView
        vc?.gameLevel = str_lvl
        vc?.appraisel = appraiselStr
        if LevelType.easy.rawValue == str_lvl {
        vc?.time = String(format: "%d", timerValue)
        }else{
        vc?.score = self.lbl_bestTime.text
        }
        
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    @objc func handleLongGesture(gesture: UILongPressGestureRecognizer) {
        switch(gesture.state) {
            
        case .began:
            guard let selectedIndexPath = collect.indexPathForItem(at: gesture.location(in: collect)) else {
                break
            }
            collect.beginInteractiveMovementForItem(at: selectedIndexPath)
        case .changed:
        collect.updateInteractiveMovementTargetPosition(gesture.location(in: gesture.view!))
        case .ended:
            collect.endInteractiveMovement()
            
        default:
            collect.cancelInteractiveMovement()
        }
    }
}
